from enum import Enum
from pydantic import BaseModel
from typing import Optional

class CreateUser_activityBody(BaseModel):
    # email: str
    # password: str
    pass
    
class UpdateUser_activityBody(BaseModel):
    # email: str
    # password: str
    pass
    